﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MilesPerGallon.Models
{
    public class DataPage
    {
        /*FirstName, LastName, CarModel, MilesDriven, GallonsFilled, FillUpDate*/

        public int Id { get; set; }
        [Required(ErrorMessage = "Please Enter a Valid Name")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please Enter a Valid Name")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Please Enter a Valid Car Model")]
        [Display(Name = "Car Model")]
        public string CarModel { get; set; }
        [Required(ErrorMessage = "Please Enter Valid Mileage")]
        [Display(Name = "Miles Driven")]
        public float MilesDriven { get; set; }
        [Required(ErrorMessage = "Please Enter a Valid Amount of Gas Filled")]
        [Display(Name = "Gallons Filled")]
        public int GallonsFilled { get; set; }
        [Required(ErrorMessage = "Please Enter a Valid Date")]
        [Display(Name = "Date of fill up")]
        [DataType(DataType.Date)]
        public DateTime FillUpDate { get; set; }
    }
    //public static DataPage GetInfo(DataPage searchInformation, string userSearch)
    //{
    //    Console.WriteLine("The result is: ");

    //    if (userSearch == searchInformation.FirstName)
    //    {
    //        return searchInformation;
    //    }
    //    else if (userSearch == searchInformation.LastName)
    //    {
    //        return searchInformation;
    //    }
    //    else if (userSearch == searchInformation.CarModel)
    //    {
    //        return searchInformation;
    //    }
    //    else if (float.Parse(userSearch) == searchInformation.MilesDriven)
    //    {
    //        return searchInformation;
    //    }
    //    else if (int.Parse(userSearch) == searchInformation.GallonsFilled)
    //    {
    //        return searchInformation;
    //    }
    //    else if (DateTime.Parse(userSearch) == searchInformation.FillUpDate)
    //    {
    //        return searchInformation;
    //    }
    //    else
    //    {
    //        return null;
    //    }


    //}
}
